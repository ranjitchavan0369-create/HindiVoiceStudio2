package com.example.hindivoicestudio;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.File;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {
    private TextToSpeech tts;
    private EditText textInput;
    private TextView status;
    private Button speakButton, saveButton, stopButton;
    private SeekBar speedBar;
    private boolean ttsReady = false;
    private File lastAudioFile;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int lang = tts.setLanguage(new Locale("hi", "IN"));
                ttsReady = lang != TextToSpeech.LANG_MISSING_DATA
                        && lang != TextToSpeech.LANG_NOT_SUPPORTED;
                status.setText(ttsReady
                    ? "Hindi voice ready. Offline use depends on installed voice data."
                    : "Hindi voice not found. Install Hindi speech data in your phone settings.");
                speakButton.setEnabled(ttsReady);
                saveButton.setEnabled(ttsReady);
            } else {
                status.setText("Could not start Android Text-to-Speech.");
            }
        });

        if (android.os.Build.VERSION.SDK_INT >= 21) {
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) {}
                @Override public void onDone(String id) {
                    runOnUiThread(() -> status.setText("Speech finished."));
                }
                @Override public void onError(String id) {
                    runOnUiThread(() -> status.setText("Speech failed. Try a shorter text."));
                }
            });
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(18);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Hindi Voice Studio");
        title.setTextSize(26);
        title.setTextColor(0xFF202124);
        title.setPadding(0, 0, 0, dp(8));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Type Hindi text, then speak it aloud offline.");
        subtitle.setTextSize(15);
        root.addView(subtitle);

        textInput = new EditText(this);
        textInput.setHint("यहाँ हिंदी टेक्स्ट लिखें या पेस्ट करें…");
        textInput.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
        textInput.setMinLines(7);
        textInput.setTextSize(18);
        textInput.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        textParams.topMargin = dp(18);
        root.addView(textInput, textParams);

        TextView speedLabel = new TextView(this);
        speedLabel.setText("Speech speed");
        speedLabel.setTextSize(16);
        speedLabel.setPadding(0, dp(14), 0, 0);
        root.addView(speedLabel);

        speedBar = new SeekBar(this);
        speedBar.setMax(15);
        speedBar.setProgress(5);
        root.addView(speedBar);

        speakButton = makeButton("▶  Speak Hindi");
        saveButton = makeButton("♫  Save audio file");
        stopButton = makeButton("■  Stop");
        speakButton.setEnabled(false);
        saveButton.setEnabled(false);
        root.addView(speakButton);
        root.addView(saveButton);
        root.addView(stopButton);

        Button aiButton = makeButton("AI voices (coming next)");
        aiButton.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("AI voice mode")
            .setMessage("Online AI voices are not connected in this starter version. We will add a free-tier provider after the offline app works. Do not put secret API keys directly in an APK.")
            .setPositiveButton("OK", null).show());
        root.addView(aiButton);

        status = new TextView(this);
        status.setText("Checking for Hindi speech data…");
        status.setTextSize(14);
        status.setPadding(0, dp(16), 0, dp(12));
        root.addView(status);

        TextView note = new TextView(this);
        note.setText("Tip: if Hindi speech is unavailable, open your phone's Settings and search for Text-to-speech output or Speech Services by Google, then install Hindi voice data.");
        note.setTextSize(13);
        note.setTextColor(0xFF5F6368);
        root.addView(note);

        setContentView(scroll);

        speakButton.setOnClickListener(v -> speakText());
        stopButton.setOnClickListener(v -> {
            if (tts != null) tts.stop();
            status.setText("Stopped.");
        });
        saveButton.setOnClickListener(v -> saveAudio());
    }

    private Button makeButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(7);
        b.setLayoutParams(p);
        return b;
    }

    private void speakText() {
        String text = textInput.getText().toString().trim();
        if (text.isEmpty()) {
            textInput.setError("पहले हिंदी टेक्स्ट लिखें");
            return;
        }
        if (!ttsReady || tts == null) {
            status.setText("Hindi voice is unavailable. Install Hindi voice data first.");
            return;
        }
        float rate = 0.5f + (speedBar.getProgress() * 0.1f);
        tts.setSpeechRate(rate);
        Bundle params = new Bundle();
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, UUID.randomUUID().toString());
        int result = tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, UUID.randomUUID().toString());
        status.setText(result == TextToSpeech.SUCCESS ? "Speaking…" : "Could not start speech.");
    }

    private void saveAudio() {
        String text = textInput.getText().toString().trim();
        if (text.isEmpty()) {
            textInput.setError("पहले हिंदी टेक्स्ट लिखें");
            return;
        }
        File dir = new File(getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC), "HindiVoiceStudio");
        if (!dir.exists() && !dir.mkdirs()) {
            status.setText("Could not create audio folder.");
            return;
        }
        lastAudioFile = new File(dir, "hindi_voice_" + System.currentTimeMillis() + ".wav");
        String id = "save_" + UUID.randomUUID();
        tts.setSpeechRate(0.9f);
        int result = tts.synthesizeToFile(text, new Bundle(), lastAudioFile, id);
        if (result == TextToSpeech.SUCCESS) {
            status.setText("Creating WAV audio… Saved inside app storage when complete.");
            Toast.makeText(this, "Audio generation started", Toast.LENGTH_SHORT).show();
        } else {
            status.setText("Could not create audio. Try shorter text or another Hindi voice.");
        }
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
